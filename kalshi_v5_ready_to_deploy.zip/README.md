# Kalshi V5: iPhone-friendly dashboard

A **read-only** research dashboard for Kalshi BTC 15-minute markets. It retrieves open markets from Kalshi's public API when refreshed. It does not trade, does not connect to an account, does not predict outcomes, and defaults to **PASS** until a genuinely validated external model is built.

## Deploy from an iPhone

1. In Safari, sign into https://github.com and create a repository (e.g. `kalshi-v5-dashboard`).
2. Upload `app.py` and `requirements.txt` into the repository root (GitHub website: **Add file > Upload files**; select files from iPhone Files app). You may need Safari's desktop-site view.
3. Visit https://share.streamlit.io/ and sign in with GitHub.
4. Choose **Create app**, select your repo, main branch, and `app.py`, then deploy.
5. Open your resulting Streamlit URL in Safari and use **Share > Add to Home Screen**.

Do not share a private trading API key; this dashboard requires none. If the app is public, anyone with its link may view market data and any numbers you enter. This app does not persist input probabilities.

## Run locally

```sh
pip install -r requirements.txt
streamlit run app.py
```

## Notes

- Public market endpoint: `https://external-api.kalshi.com/trade-api/v2/markets?series_ticker=KXBTC15M&status=open&limit=30`
- Uses market `yes_ask_dollars`/`no_ask_dollars` where available, falling back to legacy integer cents fields. Ask quotes are *not* guaranteed executable.
- 15-second data cache; click Refresh to request new data.
- Hypothetical EV uses `probability × $1 - ask - assumed costs`. It is not based on a trained model or actual fees.
- Production-grade V5 needs market-rule parsing, benchmark stream, actual fee handling, orderbook and fill-model, and walk-forward backtesting before considering real trading.
