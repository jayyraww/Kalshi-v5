import datetime as dt
import math
import requests
import streamlit as st

API = 'https://external-api.kalshi.com/trade-api/v2'
SERIES = 'KXBTC15M'
st.set_page_config(page_title='Kalshi V5 | BTC Dashboard', page_icon='📈', layout='centered')
st.markdown('''<style>.block-container{padding-top:1.6rem;max-width:760px}div[data-testid="stMetric"]{background:#152230;border:1px solid #334155;border-radius:12px;padding:12px}</style>''', unsafe_allow_html=True)
st.title('📈 Kalshi V5')
st.caption('BTC 15-minute monitor • research & paper trading only • no order execution')

@st.cache_data(ttl=15, show_spinner=False)
def get_markets():
    r=requests.get(f'{API}/markets',params={'series_ticker':SERIES,'status':'open','limit':30},timeout=10)
    r.raise_for_status()
    return r.json().get('markets',[])

def cents(m, side):
    key=f'{side}_ask_dollars'
    if m.get(key) not in (None,''):
        return int(round(float(m[key])*100))
    legacy=m.get(f'{side}_ask')
    return int(legacy) if legacy not in (None,'') else None

def utc(s):
    try:return dt.datetime.fromisoformat(s.replace('Z','+00:00'))
    except (AttributeError,ValueError):return None

if st.button('↻ Refresh prices', use_container_width=True): st.cache_data.clear()
try:
    markets=get_markets()
except (requests.RequestException, ValueError) as ex:
    st.error('Live market data is unavailable right now. Try Refresh later.')
    st.caption(f'Connection detail: {type(ex).__name__}')
    st.stop()
if not markets:
    st.warning('No open BTC 15-minute markets returned. Try again after the next market opens.')
    st.stop()
now=dt.datetime.now(dt.timezone.utc)
markets.sort(key=lambda x: utc(x.get('close_time')) or dt.datetime.max.replace(tzinfo=dt.timezone.utc))
options={f"{m.get('ticker','Unknown')} · {m.get('title','BTC 15m')}":m for m in markets}
selection=st.selectbox('Open BTC 15-minute market',list(options))
m=options[selection]
yes,no=cents(m,'yes'),cents(m,'no')
end=utc(m.get('close_time'))
remaining=max(0,int((end-now).total_seconds())) if end else None
c1,c2,c3=st.columns(3)
c1.metric('YES ask',f'{yes}¢' if yes is not None else 'N/A')
c2.metric('NO ask',f'{no}¢' if no is not None else 'N/A')
c3.metric('Time left',f'{remaining//60}m {remaining%60}s' if remaining is not None else 'N/A')
st.caption(f"Market: {m.get('ticker','—')} • Updated on manual refresh / page rerun • prices may become stale")
st.write(m.get('title',''))
with st.expander('Market rules and raw details'):
    st.write('Read the exact settlement rules on Kalshi before trading. Displayed asks can change before execution.')
    st.json({k:m.get(k) for k in ['ticker','subtitle','yes_sub_title','no_sub_title','close_time','status','volume_fp','liquidity_dollars'] if k in m})
st.divider()
st.subheader('Signal engine')
st.info('**PASS — no independently trained probability model connected.** Market prices alone cannot establish positive expected value.')
manual=st.toggle('Research mode: enter my own probability estimate',value=False)
if manual:
    st.warning('Manual estimates are unvalidated. Any apparent edge is hypothetical; not a verified buy signal.')
    p=st.slider('Your hypothetical probability of YES (%)',0,100,50)/100
    fee=st.number_input('Assumed total fees and slippage per contract (¢)',min_value=0.0,max_value=30.0,value=2.0,step=0.5)
    cushion=st.number_input('Safety margin (percentage points)',min_value=0.0,max_value=30.0,value=5.0,step=1.0)
    a,b=st.columns(2)
    for container,side,price,prob in [(a,'YES',yes,p),(b,'NO',no,1-p)]:
        with container:
            st.markdown(f'**{side}**')
            if price is None:
                st.write('No quoted ask available')
            else:
                gross=prob*100-price
                after=gross-fee
                st.metric('Hypothetical net EV / contract',f'{after:+.1f}¢')
                st.caption(f'Break-even incl. assumed costs: {(price+fee):.1f}%')
                if after > cushion:
                    st.write('🟡 **Candidate for further research** (not a trade recommendation)')
                else: st.write('🔴 **PASS**')
st.divider()
st.subheader('Risk guardrails')
x,y=st.columns(2)
x.metric('Paper bankroll','$100')
y.metric('Max paper risk/trade','$2')
st.caption('Suggested daily paper stop: $6. No trades are submitted, no orders tracked, and no account credentials are required.')
st.caption('For a real model: gather BTC benchmark prices, contract thresholds, timed historical order prices, settlement outcomes, and test on future unseen windows with fees and fill constraints.')
